---
name: safe-repo-preflight
description: >-
  Use before changing, committing or pushing in any of the user's repos: read repo rules, hooks and CI, work on a branch, run checks, open a PR, never force-push.
---
# Safe repo preflight

Run before every change, commit or push in any project folder (code, drawings, docs, data).

## When to use
Read and follow the repo's AGENTS.md, decisions, CONTRIBUTING.md, hooks and CI first; work on a branch in your own clone or worktree; never bypass hooks or gates; never force-push; pull ff-only only after a merge you made. Their rules and decisions still bind. A layout difference is migrated into the template, keeping every rule.

## Steps
1. **Read the repo's rules first.** Before anything else, read and follow the repo's `AGENTS.md`, decisions, `CONTRIBUTING.md`, hooks (`.pre-commit-config.yaml`, `git config core.hooksPath`, `.git/hooks`), and CI workflows. Their rules and decisions still bind. If a planned step would bypass a hook or CI gate, stop and ask the user. Never `--no-verify`. If an older agent doc's layout differs from the workstation-core template, that layout is migrated into the template by session-start, state-init, or repo-cleanup, keeping every rule. A layout difference is not a blocker or a reason to stop.
2. **Your own copy.** Work in your own scratch clone, or your own git worktree on a branch. Never write into another bot's or the user's working copy, unless the repo's `AGENTS.md`, decisions, or `CONTRIBUTING.md` say otherwise (step 1 wins). The only other exception is the ff-only pull in step 10.
3. **Status first.** `git status` and current branch. If the tree is dirty with unrelated work, stop and report; don't pile on. If git shows changes you didn't make, check `git diff --ignore-cr-at-eol`. If it's only line endings, the fix is a repo `.gitattributes` (preferred) or a repo-local `core.autocrlf`, done through a PR.
4. **Branch, never main.** All repo work goes through a PR: make a branch, push it, open a PR. Never edit on `main`/`master`, not even uncommitted, since a fast-forward can wipe it.
5. **Run the checks.** After every edit and before every commit, run the repo's required check scripts and report pass/fail. Never call work done while a check is red.
6. **Scope the commit.** Stage only the files for this task. Don't mix in personal files or unrelated changes.
7. **Never skip a hook.** No `--no-verify` or other skip, not even to push a fix. If a hook or gate fails on a generated or bot-owned file (for example, a generated docs page that a CI workflow publishes), don't touch it: leave it to the repo's workflow, say so in the PR, and ask the user.
8. **No secrets, no force-push.** Never print tokens or secrets. Run the repo's secret scanner if it has one (gitleaks or a pre-commit hook), else scan the diff for tokens, passwords and home paths. Never force-push.
9. **Push, PR, merge.** Who may merge follows the repo's `AGENTS.md`, decisions, and `CONTRIBUTING.md`. Pushing or merging needs the user's OK unless a standing rule covers it. After a push, confirm the branch on origin matches what you intended (log/SHA).
9b. **Leftover steps.** Any "after merge" or "not done here" step in the PR gets a home through state-closeout, by the tier rule: live state in your STATE file in the memory store (`STATE.md`, or `STATE-<slug>.md` on a branch), later work in BACKLOG, a decision in DECISIONS; the PR body's `State:` line names where it went.
10. **After the merge.** The bot that merged pulls, once a PR it opened or merged lands: every local copy of the repo, fast-forward only. Never overwrite uncommitted changes; if a copy is dirty or has diverged, stop and report. Then clean up only your own branch and worktree, and get the user's OK before deleting anything.
11. **If you committed to main by mistake.** Stop pushing. Report. Offer a PR or revert path; don't paper over it.

## Never
- **No surprise pulls.** Nothing scheduled, hooked or run as a routine pulls or overwrites local work.
- **Batch git shortcuts** (pull all, push all, commit all): don't add new ones without the user's OK. Existing user helpers stay as they are.
- **Frozen dependencies.** Some projects freeze specific dependencies; check that project's own rules (AGENTS.md) and never change them.

## Run alone vs. from session-start
Run by hand, this skill does only its own job and never loads another skill. If it finds something worth fixing, it may **suggest** one ("want me to run repo-cleanup?"). Only `session-start` offers the full chain, and it asks the user before each step.
